---
name: "sprint-carry-over-map"
description: "Use when asked to build a sprint carry-over map, analyse items carried over between sprints, or show cycle time in sprints on a sprint calendar, from Azure DevOps, Jira, a backlog export, or dummy data."
---

# Sprint Carry-Over Map

> Made by Dr David Michel, The Agile Broadcast. Try the online version, or get the latest copy of this skill, at https://theagilebroadcast.com/carry-over.html

This skill builds an interactive dashboard of backlog items carried over from sprint to sprint. Cycle time is measured in **number of sprints touched**: an item done in the sprint it started counts as 1.

The dashboard has:
- summary stats
- auto-written insights
- a sprint calendar with one row per item, where the bar spans the sprints it was active: the first sprint is solid, carried sprints are hatched, and open items fade at the current sprint
- a sprints-to-done distribution
- a type × category heatmap
- a new vs carried-in chart per sprint

The template at the end of this file is the approved design. Reproduce it **exactly**: the same layout, tokens, fonts, copy, light/dark theming and interactions. Change only the edit points in section 5.

## 1. Pick the data source

Use the first source that applies:

- **Azure DevOps API:** the user names an ADO org, project or team, or asks to pull from ADO. Follow section 2.
- **Jira REST API:** the user names a Jira site, project or board, or asks to pull from Jira. Follow section 3. Always call the Jira REST API with the script. Never use an Atlassian or Jira MCP connector, even if one is connected.
- **An export:** the user gives a CSV, an export or a pasted table. Build the data shape in section 4.
- **Dummy data:** nothing given. Keep the template's seeded generator unchanged. It produces 86 items over 12 two-week sprints with realistic patterns.

Both APIs output the same `data.json` (section 4), so everything after fetching is the same.

### Rules for tokens and network

These apply to every API token (ADO PAT, Jira API token or PAT):

- **Claude Code:** read tokens from environment variables. Never ask the user to paste one.
- **claude.ai:** if the user pastes a token, pass it only as an environment variable on the one command that runs the script. Never echo it, write it to a file, save it to memory or put it in the page. Remind them to revoke it afterwards.
- **Read-only:** ask for read-only scopes only.
- **Network:** the claude.ai workspace usually blocks the API hosts. Test once with `curl -s -o /dev/null -w "%{http_code}" <base url>`. If it is refused, offer two options: add the domain under Settings > Capabilities (their admin does this on Team or Enterprise plans), or run in Claude Code. Do not retry through other routes.

## 2. Azure DevOps

### What you need

| Item | Detail |
|---|---|
| Org | the organization name |
| Project | the project name |
| Team | defaults to `<project> Team`; ask if unsure |
| Sprint count | default 12 |
| Category source | Area Path last segment (default) or first tag |
| Work item types | optional filter |
| Area Path prefix | optional filter |
| PAT | scopes **Analytics (read)** and **Work Items (read)** |

The hosts are `dev.azure.com` and `analytics.dev.azure.com`.

### Run the script

Write the script to a scratch file and run:

```
ADO_ORG=… ADO_PROJECT=… ADO_TEAM=… ADO_PAT=… python3 ado_carryover.py --sprints 12 [--category area|tag] [--types "User Story,Bug"] [--area "Project\Team"] > data.json
```

**Why revisions.** The current Iteration Path shows only the sprint an item ended in, which hides carry-over. The script reads every revision from the Analytics `WorkItemRevisions` endpoint. A sprint counts as touched when the item sat in that iteration at any moment between the sprint's start and finish dates. Moving an item before a sprint starts therefore does not count that sprint.

**Done and open.**
- Removed items are dropped.
- `open` means the latest state category is not Resolved or Completed.

**Errors.**
- 401 or 403: the PAT is missing the Analytics scope, or org policy blocks it.
- "No past/current sprints": the team name is wrong.

```python
#!/usr/bin/env python3
"""Fetch sprint carry-over data from Azure DevOps.

Env: ADO_ORG, ADO_PROJECT, ADO_PAT (read-only, Analytics + Work Items read), ADO_TEAM (optional, defaults to "<project> Team")
Usage: python3 ado_carryover.py --sprints 12 [--category area|tag] [--types "User Story,Bug"] [--area "Project\\Team"] > data.json
"""
import argparse, base64, json, os, sys, urllib.parse, urllib.request
from datetime import datetime, timezone

def get(url, pat):
    req = urllib.request.Request(url, headers={
        "Authorization": "Basic " + base64.b64encode((":" + pat).encode()).decode(),
        "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)

def dt(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00")) if s else None

def q(s):
    return "'" + s.replace("'", "''") + "'"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sprints", type=int, default=12)
    ap.add_argument("--category", choices=["area", "tag"], default="area")
    ap.add_argument("--types", default="")
    ap.add_argument("--area", default="")
    a = ap.parse_args()
    org, proj, pat = os.environ["ADO_ORG"], os.environ["ADO_PROJECT"], os.environ["ADO_PAT"]
    team = os.environ.get("ADO_TEAM") or proj + " Team"
    P = urllib.parse.quote

    # 1. Team sprints up to and including the current one
    its = get(f"https://dev.azure.com/{P(org)}/{P(proj)}/{P(team)}/_apis/work/teamsettings/iterations?api-version=7.1", pat)["value"]
    its = [i for i in its if i["attributes"].get("startDate") and i["attributes"].get("timeFrame") in ("past", "current")]
    its.sort(key=lambda i: i["attributes"]["startDate"])
    its = its[-a.sprints:]
    if not its:
        sys.exit("No past/current sprints with dates found for team " + team)
    sprints = [{"name": i["name"], "path": i["path"],
                "start": dt(i["attributes"]["startDate"]), "end": dt(i["attributes"]["finishDate"])} for i in its]
    cur = next((k for k, i in enumerate(its) if i["attributes"]["timeFrame"] == "current"), len(its) - 1)
    idx = {s["path"]: k for k, s in enumerate(sprints)}

    # 2. Every revision of items that were ever in those sprints
    flt = "Iteration/IterationPath in (" + ",".join(q(s["path"]) for s in sprints) + ")"
    if a.types:
        flt += " and WorkItemType in (" + ",".join(q(t.strip()) for t in a.types.split(",")) + ")"
    if a.area:
        flt += " and startswith(Area/AreaPath," + q(a.area) + ")"
    ids_url = (f"https://analytics.dev.azure.com/{P(org)}/{P(proj)}/_odata/v4.0-preview/WorkItemRevisions?"
               + urllib.parse.urlencode({"$apply": "filter(" + flt + ")/groupby((WorkItemId))"}))
    ids = sorted({r["WorkItemId"] for r in get(ids_url, pat)["value"]})
    revs = []
    for c in range(0, len(ids), 100):
        chunk = ids[c:c + 100]
        url = (f"https://analytics.dev.azure.com/{P(org)}/{P(proj)}/_odata/v4.0-preview/WorkItemRevisions?"
               + urllib.parse.urlencode({
                   "$filter": "WorkItemId in (" + ",".join(map(str, chunk)) + ")",
                   "$select": "WorkItemId,Revision,ChangedDate,Title,WorkItemType,State,StateCategory,StoryPoints,TagNames",
                   "$expand": "Iteration($select=IterationPath),Area($select=AreaPath)",
                   "$orderby": "WorkItemId,Revision"}))
        while url:
            page = get(url, pat)
            revs += page["value"]
            url = page.get("@odata.nextLink")

    # 3. A sprint counts as touched if the item sat in it at any moment during that sprint's dates
    now = datetime.now(timezone.utc)
    by = {}
    for r in revs:
        by.setdefault(r["WorkItemId"], []).append(r)
    items = []
    for wid, rs in by.items():
        rs.sort(key=lambda r: r["Revision"])
        last = rs[-1]
        if last.get("StateCategory") == "Removed":
            continue
        touched = set()
        for k, r in enumerate(rs):
            k_idx = idx.get((r.get("Iteration") or {}).get("IterationPath"))
            if k_idx is None:
                continue
            frm = dt(r["ChangedDate"])
            to = dt(rs[k + 1]["ChangedDate"]) if k + 1 < len(rs) else now
            s = sprints[k_idx]
            if frm <= s["end"] and to >= s["start"]:
                touched.add(k_idx)
        if not touched:
            continue
        if a.category == "tag":
            tags = [t.strip() for t in (last.get("TagNames") or "").split(";") if t.strip()]
            cat = tags[0] if tags else "Untagged"
        else:
            cat = ((last.get("Area") or {}).get("AreaPath") or "").split("\\")[-1] or "No area"
        start, end = min(touched), max(touched)
        is_open = last.get("StateCategory") not in ("Resolved", "Completed")
        items.append({"id": str(wid), "title": last.get("Title") or "", "type": last.get("WorkItemType"),
                      "cat": cat, "start": start, "end": end, "open": is_open,
                      "pts": last.get("StoryPoints") or 0})

    json.dump({"team": team, "current": cur,
               "sprints": [{"name": s["name"], "date": s["start"].strftime("%-d %b")} for s in sprints],
               "items": items}, sys.stdout, indent=1)

if __name__ == "__main__":
    main()
```

## 3. Jira REST API

### How Jira records carry-over

Jira's Sprint field keeps **every sprint an issue was in**. When a sprint is completed with unfinished work, the issue keeps the closed sprint and gains the next one. So the Sprint field alone gives sprints touched; no changelog is needed.

One limit applies: an issue removed from a sprint before that sprint closed drops it from the field. Mention this in your reply when using Jira data.

### What you need

| Item | Detail |
|---|---|
| Site URL | e.g. `https://acme.atlassian.net`, or the Server/DC URL |
| Board ID | in the board URL as `rapidView=` or `/boards/42` |
| Sprint count | default 12 |
| Category source | first component (default), first label, or epic |
| Issue types | optional filter |
| Credentials | see below |

**Credentials.**
- **Jira Cloud:** an API token (created at id.atlassian.com > Security > API tokens) in `JIRA_TOKEN`, plus the account email in `JIRA_EMAIL`.
- **Server/Data Center:** a personal access token in `JIRA_TOKEN`, with `JIRA_EMAIL` left unset.

### Run the script

Write the script to a scratch file and run:

```
JIRA_BASE_URL=… JIRA_EMAIL=… JIRA_TOKEN=… python3 jira_carryover.py --board 42 --sprints 12 [--category component|label|epic] [--types "Story,Bug"] > data.json
```

What the script does:
- Finds the Sprint and story points fields itself.
- Reads the board's last N sprints from the Agile API.
- Fetches every issue in them: `/rest/api/3/search/jql` on Cloud, `/rest/api/2/search` on Server/DC.
- Optionally, `--input saved.json` re-runs the transform on a list of issues saved from an earlier API call, without calling Jira again.

**Done and open.** `open` means the status category is not Done. The current sprint is the latest active one.

**Errors.**
- 401: wrong email/token pair, or an API token used on Server.
- 404 on the board: wrong board ID.
- "Could not find the Sprint field": the board isn't a Scrum board.

```python
#!/usr/bin/env python3
"""Fetch sprint carry-over data from the Jira REST API (Cloud or Server/Data Center).

Env: JIRA_BASE_URL (e.g. https://acme.atlassian.net), JIRA_TOKEN (API token or PAT),
     JIRA_EMAIL (Cloud only; leave unset for a Server/DC personal access token)
  python3 jira_carryover.py --board 42 --sprints 12 [--category component|label|epic] [--types "Story,Bug"] > data.json
Re-run the transform on issues saved from an earlier API call (no network):
  python3 jira_carryover.py --input saved.json [--board 42] --sprints 12 [--category ...] [--points-field customfield_10016] > data.json
"""
import argparse, base64, json, os, re, sys, urllib.parse, urllib.request
from datetime import datetime, timezone

SPRINT_SCHEMA = "com.pyxis.greenhopper.jira:gh-sprint"

def get(path, params=None):
    base = os.environ["JIRA_BASE_URL"].rstrip("/")
    tok, email = os.environ["JIRA_TOKEN"], os.environ.get("JIRA_EMAIL")
    auth = ("Basic " + base64.b64encode(f"{email}:{tok}".encode()).decode()) if email else ("Bearer " + tok)
    url = base + path + ("?" + urllib.parse.urlencode(params) if params else "")
    req = urllib.request.Request(url, headers={"Authorization": auth, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)

def dt(s):
    if not s:
        return None
    s = s.replace("Z", "+00:00")
    s = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", s)
    return datetime.fromisoformat(s)

def parse_sprint(v):
    """Cloud returns dicts; older Server returns 'com.atlassian...Sprint@x[id=1,rapidViewId=2,state=CLOSED,name=..,startDate=..]'."""
    if isinstance(v, dict):
        return {"id": v.get("id"), "name": v.get("name"), "state": (v.get("state") or "").lower(),
                "board": v.get("boardId") or v.get("originBoardId"), "start": v.get("startDate"), "end": v.get("endDate")}
    m = dict(re.findall(r"(\w+)=([^,\]]*)", str(v)))
    return {"id": int(m["id"]) if m.get("id", "").isdigit() else m.get("id"), "name": m.get("name"),
            "state": (m.get("state") or "").lower(), "board": int(m["rapidViewId"]) if m.get("rapidViewId", "").isdigit() else None,
            "start": None if m.get("startDate") in (None, "", "<null>") else m["startDate"],
            "end": None if m.get("endDate") in (None, "", "<null>") else m["endDate"]}

def find_sprint_field(issues):
    for iss in issues:
        for k, v in (iss.get("fields") or {}).items():
            if isinstance(v, list) and v and (
                (isinstance(v[0], dict) and "state" in v[0] and ("boardId" in v[0] or "startDate" in v[0]))
                or (isinstance(v[0], str) and "Sprint@" in v[0])):
                return k
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--board", type=int)
    ap.add_argument("--input")
    ap.add_argument("--sprints", type=int, default=12)
    ap.add_argument("--category", choices=["component", "label", "epic"], default="component")
    ap.add_argument("--types", default="")
    ap.add_argument("--points-field")
    a = ap.parse_args()

    sprint_field, points_field = None, a.points_field
    if a.input:
        issues = json.load(open(a.input))
        if isinstance(issues, dict):
            issues = issues.get("issues", [])
    else:
        if not a.board:
            sys.exit("--board is required")
        fields = get("/rest/api/2/field")
        sprint_field = next((f["id"] for f in fields if (f.get("schema") or {}).get("custom") == SPRINT_SCHEMA), None)
        if not points_field:
            points_field = next((f["id"] for f in fields if f.get("name", "").lower() in ("story points", "story point estimate")), None)
        # board sprints, newest last
        sp, start = [], 0
        while True:
            page = get(f"/rest/agile/1.0/board/{a.board}/sprint", {"state": "active,closed", "startAt": start, "maxResults": 50})
            sp += page["values"]
            if page.get("isLast", True) or not page["values"]:
                break
            start += len(page["values"])
        sp = sorted([s for s in sp if s.get("startDate")], key=lambda s: s["startDate"])[-a.sprints:]
        if not sp:
            sys.exit(f"No active or closed sprints with dates on board {a.board}")
        jql = "sprint in (" + ",".join(str(s["id"]) for s in sp) + ")"
        if a.types:
            jql += " AND issuetype in (" + ",".join('"' + t.strip() + '"' for t in a.types.split(",")) + ")"
        want = ["summary", "issuetype", "status", "components", "labels", "parent", sprint_field] + ([points_field] if points_field else [])
        flds = ",".join(f for f in want if f)
        issues = []
        if os.environ.get("JIRA_EMAIL"):  # Cloud: enhanced search with page tokens
            tok = None
            while True:
                params = {"jql": jql, "fields": flds, "maxResults": 100}
                if tok:
                    params["nextPageToken"] = tok
                page = get("/rest/api/3/search/jql", params)
                issues += page.get("issues", [])
                tok = page.get("nextPageToken")
                if page.get("isLast", True) or not tok:
                    break
        else:  # Server / Data Center
            start = 0
            while True:
                page = get("/rest/api/2/search", {"jql": jql, "fields": flds, "startAt": start, "maxResults": 100})
                issues += page["issues"]
                start += len(page["issues"])
                if start >= page.get("total", 0) or not page["issues"]:
                    break

    sprint_field = sprint_field or find_sprint_field(issues)
    if not sprint_field:
        sys.exit("Could not find the Sprint field on these issues")

    # Collect sprints from the issues themselves
    allsp = {}
    for iss in issues:
        for v in (iss["fields"].get(sprint_field) or []):
            s = parse_sprint(v)
            if s["start"] and s["state"] in ("active", "closed"):
                allsp[s["id"]] = s
    board = a.board
    if board is None:
        counts = {}
        for s in allsp.values():
            counts[s["board"]] = counts.get(s["board"], 0) + 1
        board = max(counts, key=counts.get) if counts else None
    win = sorted([s for s in allsp.values() if board is None or s["board"] in (board, None)], key=lambda s: dt(s["start"]))[-a.sprints:]
    if not win:
        sys.exit("No active or closed sprints found on these issues")
    idx = {s["id"]: k for k, s in enumerate(win)}
    actives = [k for k, s in enumerate(win) if s["state"] == "active"]
    cur = actives[-1] if actives else len(win) - 1

    items = []
    for iss in issues:
        f = iss["fields"]
        if a.types and (f.get("issuetype") or {}).get("name") not in [t.strip() for t in a.types.split(",")]:
            continue
        touched = {idx[parse_sprint(v)["id"]] for v in (f.get(sprint_field) or []) if parse_sprint(v)["id"] in idx}
        if not touched:
            continue
        if a.category == "label":
            cat = (f.get("labels") or ["No label"])[0]
        elif a.category == "epic":
            p = f.get("parent") or {}
            cat = ((p.get("fields") or {}).get("summary")) or "No epic"
        else:
            comps = f.get("components") or []
            cat = comps[0]["name"] if comps else "No component"
        done = ((f.get("status") or {}).get("statusCategory") or {}).get("key") == "done"
        pts = f.get(points_field) if points_field else 0
        items.append({"id": iss["key"], "title": f.get("summary") or "", "type": (f.get("issuetype") or {}).get("name") or "Issue",
                      "cat": cat, "start": min(touched), "end": max(touched), "open": not done,
                      "pts": pts if isinstance(pts, (int, float)) else 0})

    json.dump({"team": f"board {board}" if board else "Jira", "current": cur,
               "sprints": [{"name": s["name"], "date": dt(s["start"]).strftime("%-d %b")} for s in win],
               "items": items}, sys.stdout, indent=1)

if __name__ == "__main__":
    main()
```

## 4. Data shape

Real data, from either API or an export, uses this JSON shape:

```
{team, current, sprints:[{name, date}], items:[{id, title, type, cat, start, end, open, pts}]}
```

- `start` and `end` are zero-based sprint indexes.
- `current` is the index of the current sprint.
- `type` and `cat` are plain names.
- An item can skip sprints; `n` still counts every sprint from its first to its last.

For exports, build this shape yourself. Order sprints by date and use 0 for unknown points.

## 5. Edit points

Apply these only with real data:

1. **Data block.** In the script, replace everything from `const N_SPR=12` through `items.forEach(it=>{if(it.start===CUR)it.open=true});` with:

   ```js
   const DATA = /* paste data.json here */;
   const N_SPR=DATA.sprints.length, CUR=DATA.current, sprints=DATA.sprints;
   const typeTok=["--t-story","--t-bug","--t-debt","--t-spike"];
   const TYPES=[...new Set(DATA.items.map(i=>i.type))].map((n,i)=>({k:n,n,c:typeTok[i]||"--muted"}));
   const CATS=[...new Set(DATA.items.map(i=>i.cat))].map((n,i)=>({k:n,n,c:"--c"+(i+1)}));
   const items=DATA.items.map(i=>({...i,type:TYPES.find(t=>t.n===i.type),cat:CATS.find(c=>c.n===i.cat),n:i.end-i.start+1}));
   ```

2. **Colour tokens.** For more than 4 types, or 5 or 6 categories, add tokens (`--t-*`, `--c6`) in all three theme blocks (`:root`, the dark media query and `[data-theme="dark"]`). For more than 6 categories, fold the smallest into "Other".

3. **Grid columns.** In the CSS, change `repeat(12,1fr)` (it appears twice: `.row` and `.cols`) to the real sprint count.

4. **Insights.**
   - The first insight ends with a fixed claim about outside-team dependencies. Rewrite it to state only what the data shows.
   - The trend insight uses `share(1..3)` vs `share(9..11)` with labels S15–S17 / S23–S25. Change it to the first three sprints after the first vs the last three, with their real names.

5. **Copy.**
   - Header eyebrow: replace `Sample team · S14–S25 · sample data` with the real team or board, sprint range and source ("Azure DevOps" or "Jira").
   - Lede: if the sprint count or length differs, update "12 two-week sprints".

## 6. Publish and reply

- Syntax-check the page script once by extracting it and running `node --check`.
- Publish as an Artifact with the `<title>` Sprint Carry-Over Map and icon `calendar`. Deliver the `.html` file only if the user asks for a file, or if artifacts aren't available (for example in Claude Code), in which case save it as `carry-over.html`.
- **Real work data:** the page embeds item titles. Mention that the artifact is private until they share it.
- **Reply:** in one or two sentences, say what the page shows and the strongest pattern in the data.

## Template

````html
<title>Sprint Carry-Over Map</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap">
<style>
/* Layout: summary strip → insights → sprint calendar (one row per item, bars span sprints) → pattern panels */
:root{
  --bg:#f4f6f8; --surface:#ffffff; --fg:#17202b; --muted:#5d6b7a; --line:#dde3ea; --now:#fff4d6;
  --accent:#2457c5;
  --t-story:#3f78d8; --t-bug:#d6573b; --t-debt:#b88a16; --t-spike:#7d58c9;
  --c1:#2f8f83; --c2:#3f78d8; --c3:#8a6bd1; --c4:#d6573b; --c5:#b88a16;
  --d1:#cfe0d9; --d2:#f0cf86; --d3:#e8915e; --d4:#c2412f;
  --heat:#c2412f; --on-heat:#ffffff;
  --font-display:"Instrument Sans", "Segoe UI", system-ui, sans-serif;
  --font-body:"Instrument Sans", "Segoe UI", system-ui, sans-serif;
  --font-mono:"JetBrains Mono", ui-monospace, "SFMono-Regular", Menlo, monospace;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --bg:#10151c; --surface:#18202a; --fg:#e6ebf1; --muted:#93a1b1; --line:#2a3542; --now:#2e2a1c;
  --accent:#7aa5f5;
  --t-story:#6b9cf0; --t-bug:#ec7a5e; --t-debt:#d8ab3c; --t-spike:#a586ec;
  --c1:#4fb3a6; --c2:#6b9cf0; --c3:#a586ec; --c4:#ec7a5e; --c5:#d8ab3c;
  --d1:#2f4a43; --d2:#8a7130; --d3:#b8643a; --d4:#e0533c;
  --heat:#e0533c; --on-heat:#ffffff; color-scheme:dark;
}}
:root[data-theme="dark"]{
  --bg:#10151c; --surface:#18202a; --fg:#e6ebf1; --muted:#93a1b1; --line:#2a3542; --now:#2e2a1c;
  --accent:#7aa5f5;
  --t-story:#6b9cf0; --t-bug:#ec7a5e; --t-debt:#d8ab3c; --t-spike:#a586ec;
  --c1:#4fb3a6; --c2:#6b9cf0; --c3:#a586ec; --c4:#ec7a5e; --c5:#d8ab3c;
  --d1:#2f4a43; --d2:#8a7130; --d3:#b8643a; --d4:#e0533c;
  --heat:#e0533c; --on-heat:#ffffff; color-scheme:dark;
}
body{background:var(--bg);color:var(--fg);font-family:var(--font-body);font-size:15px;line-height:1.5}
.wrap{max-width:1180px;margin:0 auto;padding-block:28px 56px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));display:flex;flex-direction:column;gap:22px}
h1{font-family:var(--font-display);font-size:clamp(26px,4vw,36px);line-height:1.1;margin:0;letter-spacing:-.01em;text-wrap:balance}
h2{font-size:18px;margin:0;text-wrap:balance}
.eyebrow{font-family:var(--font-mono);font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
.lede{color:var(--muted);max-width:68ch;margin:6px 0 0}
.note{font-size:12px;color:var(--muted);margin:0}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1px;background:var(--line);border:1px solid var(--line);border-radius:10px;overflow:hidden}
.stat{background:var(--surface);padding:14px 16px}
.stat b{display:block;font-family:var(--font-mono);font-size:24px;font-weight:500;font-variant-numeric:tabular-nums}
.stat span{font-size:12px;color:var(--muted)}
.panel{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:18px;display:flex;flex-direction:column;gap:14px;min-width:0}
.insights{margin:0;padding-left:18px;display:flex;flex-direction:column;gap:6px;max-width:80ch}
.insights strong{font-weight:600}
.controls{display:flex;flex-wrap:wrap;gap:14px 22px;align-items:center}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:7px;overflow:hidden}
.seg button{font:inherit;font-size:13px;background:transparent;color:var(--fg);border:0;padding:5px 11px;cursor:pointer}
.seg button+button{border-left:1px solid var(--line)}
.seg button[aria-pressed="true"]{background:var(--fg);color:var(--surface)}
.ctl{display:flex;gap:8px;align-items:center;font-size:13px;color:var(--muted)}
button:focus-visible,input:focus-visible,.bar:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.legend{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:12px;color:var(--muted)}
.legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:-1px}
.sw-carry{background:repeating-linear-gradient(135deg,var(--muted) 0 2px,transparent 2px 5px)!important;border:1px solid var(--muted)}
/* calendar */
.cal-scroll{overflow-x:auto;margin:0 -4px;padding:0 4px}
.cal{min-width:720px;--label:150px;position:relative}
.row{display:grid;grid-template-columns:var(--label) repeat(12,1fr);align-items:center;height:20px}
.row .lbl{font-family:var(--font-mono);font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:8px}
.head{height:auto;position:sticky;top:0;background:var(--surface);z-index:2;padding-bottom:6px;border-bottom:1px solid var(--line)}
.head .sp{font-family:var(--font-mono);font-size:11px;text-align:center;line-height:1.25;color:var(--muted)}
.head .sp b{display:block;color:var(--fg);font-weight:500}
.head .sp.cur b{color:var(--accent)}
.grp{height:auto;padding:12px 0 4px;font-size:13px;font-weight:600;display:flex;gap:8px;align-items:baseline}
.grp small{font-family:var(--font-mono);font-weight:400;color:var(--muted);font-size:11px}
.cols{position:absolute;inset:0;display:grid;grid-template-columns:var(--label) repeat(12,1fr);pointer-events:none;z-index:0}
.cols div{border-left:1px dashed var(--line)}
.cols div:first-child{border:0}
.cols .cur{background:var(--now)}
.rows{position:relative;z-index:1}
.bar{grid-row:1;height:12px;display:flex;gap:2px;cursor:pointer;margin:0 3px;border-radius:3px}
.bar .s{flex:1;border-radius:2px;background:var(--c)}
.bar .s.carry{background:repeating-linear-gradient(135deg,var(--c) 0 3px,color-mix(in oklab,var(--c) 30%,transparent) 3px 6px)}
.bar.open .s:last-child{mask-image:linear-gradient(90deg,#000 40%,transparent);-webkit-mask-image:linear-gradient(90deg,#000 40%,transparent)}
.bar:hover .s,.bar.sel .s{filter:brightness(1.12)}
.bar.sel{outline:2px solid var(--fg);outline-offset:1px}
.dim .bar{opacity:.18}
#tip{position:fixed;z-index:20;background:var(--fg);color:var(--bg);padding:9px 11px;border-radius:7px;font-size:12.5px;line-height:1.4;max-width:270px;pointer-events:none;box-shadow:0 6px 20px rgba(0,0,0,.25)}
#tip .m{font-family:var(--font-mono);font-size:11px;opacity:.75}
/* pattern panels */
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,460px),1fr));gap:22px}
.dist{display:flex;flex-direction:column;gap:9px}
.drow{display:grid;grid-template-columns:130px 1fr 54px;gap:10px;align-items:center;font-size:13px}
.drow .track{display:flex;height:18px;border-radius:4px;overflow:hidden;background:var(--line)}
.drow .track div{height:100%}
.drow .avg{font-family:var(--font-mono);font-size:12px;text-align:right;font-variant-numeric:tabular-nums}
.matrix{border-collapse:separate;border-spacing:3px;width:100%;font-size:12px}
.matrix th{font-weight:500;color:var(--muted);text-align:left;padding:2px 4px}
.matrix thead th{text-align:center;font-size:11px;line-height:1.2;vertical-align:bottom}
.matrix td{text-align:center;border-radius:4px;padding:7px 2px;font-family:var(--font-mono);font-variant-numeric:tabular-nums}
.matrix td small{display:block;font-size:10px;opacity:.75}
.mx-scroll{overflow-x:auto}
svg text{fill:var(--muted);font-family:var(--font-mono);font-size:10px}
@media (max-width:520px){.cal{--label:84px}.drow{grid-template-columns:96px 1fr 44px}}
@media (prefers-reduced-motion:no-preference){.bar .s{transition:filter .15s}}
</style>

<div class="wrap">
  <header>
    <div class="eyebrow">Backlog analysis · Sample team · S14–S25 · sample data</div>
    <h1>Sprint carry-over map</h1>
    <p class="lede">Every item committed over the last 12 two-week sprints, drawn across the sprint calendar. Cycle time is counted in sprints touched: an item done in the sprint it started scores 1. Hatched segments are sprints the item was carried into.</p>
  </header>

  <section class="stats" id="stats" aria-label="Summary"></section>

  <section class="panel">
    <h2>What stands out</h2>
    <ul class="insights" id="insights"></ul>
  </section>

  <section class="panel">
    <div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:10px;align-items:baseline">
      <h2>Sprint calendar</h2>
      <p class="note">Hover or tap a bar for details. Faded end = still open in the current sprint.</p>
    </div>
    <div class="controls">
      <div class="ctl">Group by <span class="seg" id="groupBy"><button data-v="type" aria-pressed="true">Type</button><button data-v="cat" aria-pressed="false">Category</button></span></div>
      <div class="ctl">Colour by <span class="seg" id="colorBy"><button data-v="type" aria-pressed="false">Type</button><button data-v="cat" aria-pressed="true">Category</button></span></div>
      <label class="ctl" for="onlyCarry"><input type="checkbox" id="onlyCarry"> Carried over only</label>
    </div>
    <div class="legend" id="legend"></div>
    <div class="cal-scroll"><div class="cal" id="cal"></div></div>
  </section>

  <div class="grid2">
    <section class="panel">
      <h2>Sprints to done, by <span id="distBy">type</span></h2>
      <div class="legend">
        <span><i style="background:var(--d1)"></i>1 sprint</span><span><i style="background:var(--d2)"></i>2</span><span><i style="background:var(--d3)"></i>3</span><span><i style="background:var(--d4)"></i>4+</span><span style="margin-left:auto">avg</span>
      </div>
      <div class="dist" id="dist"></div>
      <p class="note">Completed items only. Follows the “Group by” switch above.</p>
    </section>
    <section class="panel">
      <h2>Where it hurts: type × category</h2>
      <div class="mx-scroll"><table class="matrix" id="matrix"></table></div>
      <p class="note">Average sprints to done (completed items), with item count. Darker = longer.</p>
    </section>
  </div>

  <section class="panel">
    <h2>How much of each sprint is inherited work</h2>
    <div class="legend"><span><i style="background:var(--accent)"></i>New this sprint</span><span><i class="sw-carry"></i>Carried in from earlier sprints</span></div>
    <div id="load"></div>
    <p class="note">Items active per sprint. A rising hatched share means the team starts each sprint with less room for new work.</p>
  </section>
</div>
<div id="tip" hidden></div>

<script>
(function(){
const N_SPR=12, CUR=11, START=new Date(2026,4,18);
const sprints=[...Array(N_SPR)].map((_,i)=>{const d=new Date(START);d.setDate(d.getDate()+14*i);return{name:"S"+(14+i),date:d.toLocaleDateString("en-GB",{day:"numeric",month:"short"})}});
const TYPES=[{k:"story",n:"Story",w:.45,f:.30,c:"--t-story",verb:"Add"},{k:"bug",n:"Bug",w:.25,f:.14,c:"--t-bug",verb:"Fix"},{k:"debt",n:"Tech debt",w:.18,f:.52,c:"--t-debt",verb:"Refactor"},{k:"spike",n:"Spike",w:.12,f:.40,c:"--t-spike",verb:"Investigate"}];
const CATS=[
 {k:"checkout",n:"Checkout",m:1.0,c:"--c1",t:["promo code stacking","guest checkout address form","basket save-for-later","delivery slot picker","order summary totals","express checkout button"]},
 {k:"search",n:"Search & browse",m:.8,c:"--c2",t:["size filter facets","sort by newest","zero-results suggestions","product tile lazy load","category landing banners","recently viewed rail"]},
 {k:"account",n:"Account",m:.95,c:"--c3",t:["saved addresses list","order history paging","email preference centre","password reset flow","returns tracker","wishlist sharing"]},
 {k:"payments",n:"Payments (3rd party)",m:1.65,c:"--c4",t:["Klarna instalments","3DS2 challenge flow","Apple Pay token refresh","refund webhook","PayPal vault","gift card balance API"]},
 {k:"platform",n:"Platform",m:1.35,c:"--c5",t:["image CDN migration","feature flag SDK upgrade","search index rebuild job","API gateway timeouts","observability dashboards","Node 22 upgrade"]}
];
let seed=20261026;const rnd=()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const pick=arr=>{let r=rnd(),a=0;for(const x of arr){a+=x.w;if(r<a)return x}return arr[arr.length-1]};
const catW=[.24,.24,.18,.16,.18];CATS.forEach((c,i)=>c.w=catW[i]);
const items=[];
for(let i=0;i<86;i++){
  const ty=pick(TYPES),ca=pick(CATS);
  const p=Math.min(.82,ty.f*ca.m);
  let n=1;while(rnd()<p&&n<7)n++;
  const start=Math.floor(rnd()*N_SPR);
  let end=start+n-1,open=false;
  if(end>CUR){end=CUR;open=true}
  const thing=ca.t[Math.floor(rnd()*ca.t.length)];
  items.push({id:"ITM-"+(2140+i*7+Math.floor(rnd()*6)),title:ty.verb+" "+thing,type:ty,cat:ca,start,end,open,n:end-start+1,pts:[1,2,3,5,8][Math.floor(rnd()*5)]});
}
items.forEach(it=>{if(it.start===CUR)it.open=true});
const done=items.filter(i=>!i.open);
const avg=a=>a.reduce((s,x)=>s+x.n,0)/(a.length||1);
const fmt=x=>x.toFixed(1);
const pct=x=>Math.round(x*100)+"%";

// stats
const carried=done.filter(i=>i.n>1);
const openCarried=items.filter(i=>i.open&&i.n>1);
const median=(()=>{const s=done.map(i=>i.n).sort((a,b)=>a-b);return s[Math.floor(s.length/2)]})();
const longest=done.reduce((m,i)=>i.n>m.n?i:m,done[0]);
document.getElementById("stats").innerHTML=[
 [items.length,"items committed"],
 [pct(carried.length/done.length),"of done items carried over"],
 [fmt(avg(done))+" sprints","average cycle time"],
 [median+" sprint"+(median>1?"s":""),"median cycle time"],
 [openCarried.length,"open items already carried"],
 [longest.n+" sprints","longest ("+longest.id+")"]
].map(([b,s])=>`<div class="stat"><b>${b}</b><span>${s}</span></div>`).join("");

// insights
const by=(arr,key)=>{const m=new Map();arr.forEach(i=>{const g=i[key];if(!m.has(g))m.set(g,[]);m.get(g).push(i)});return m};
const rest=(arr,f)=>arr.filter(i=>!f(i));
const catStats=[...by(done,"cat")].map(([c,a])=>({c,a,avg:avg(a),cr:a.filter(i=>i.n>1).length/a.length})).sort((x,y)=>y.avg-x.avg);
const typeStats=[...by(done,"type")].map(([t,a])=>({t,a,avg:avg(a),cr:a.filter(i=>i.n>1).length/a.length})).sort((x,y)=>y.avg-x.avg);
const wc=catStats[0],wt=typeStats[0],bt=typeStats[typeStats.length-1];
let cells=[];TYPES.forEach(t=>CATS.forEach(c=>{const a=done.filter(i=>i.type===t&&i.cat===c);if(a.length>=3)cells.push({t,c,a,avg:avg(a)})}));cells.sort((x,y)=>y.avg-x.avg);
const wcell=cells[0];
const share=s=>{const a=items.filter(i=>i.start<=s&&i.end>=s);return a.filter(i=>i.start<s).length/(a.length||1)};
const early=(share(1)+share(2)+share(3))/3,late=(share(9)+share(10)+share(11))/3;
document.getElementById("insights").innerHTML=[
 `<strong>${wc.c.n}</strong> items take ${fmt(wc.avg)} sprints on average and ${pct(wc.cr)} carry over, against ${fmt(avg(rest(done,i=>i.cat===wc.c)))} sprints for everything else. Work that depends on an outside team is the clearest carry-over driver.`,
 `<strong>${wt.t.n}</strong> is the slowest item type (${fmt(wt.avg)} sprints, ${pct(wt.cr)} carried). <strong>${bt.t.n}s</strong> are the most predictable at ${fmt(bt.avg)}.`,
 wcell?`The worst combination is <strong>${wcell.t.n} × ${wcell.c.n}</strong>: ${wcell.a.length} items averaging ${fmt(wcell.avg)} sprints. A candidate for smaller slices or a spike before committing.`:"",
 `Inherited work is ${late>early?"growing":"stable"}: carried-in items made up ${pct(early)} of active work in S15–S17 and ${pct(late)} in S23–S25.`
].filter(Boolean).map(s=>`<li>${s}</li>`).join("");

// calendar
const state={group:"type",color:"cat",only:false};
const tip=document.getElementById("tip");
function legend(){
  const set=state.color==="type"?TYPES:CATS;
  document.getElementById("legend").innerHTML=set.map(x=>`<span><i style="background:var(${x.c})"></i>${x.n}</span>`).join("")+`<span><i class="sw-carry"></i>Carried-over sprint</span>`;
}
function renderCal(){
  const cal=document.getElementById("cal");
  const groups=state.group==="type"?TYPES:CATS;
  let h=`<div class="cols"><div></div>${sprints.map((_,i)=>`<div class="${i===CUR?"cur":""}"></div>`).join("")}</div><div class="rows">`;
  h+=`<div class="row head"><div class="lbl">Item</div>${sprints.map((s,i)=>`<div class="sp ${i===CUR?"cur":""}"><b>${s.name}</b>${i===CUR?"now":s.date}</div>`).join("")}</div>`;
  groups.forEach(g=>{
    let a=items.filter(i=>(state.group==="type"?i.type:i.cat)===g);
    if(state.only)a=a.filter(i=>i.n>1);
    a.sort((x,y)=>x.start-y.start||y.n-x.n);
    const d=a.filter(i=>!i.open);
    h+=`<div class="row grp"><span>${g.n}</span><small>${a.length} items · avg ${d.length?fmt(avg(d)):"–"} sprints</small></div>`;
    a.forEach(it=>{
      const col=state.color==="type"?it.type.c:it.cat.c;
      const segs=[...Array(it.n)].map((_,k)=>`<span class="s ${k>0?"carry":""}"></span>`).join("");
      h+=`<div class="row"><div class="lbl" title="${it.title}">${it.id} ${it.title}</div><div class="bar ${it.open?"open":""}" tabindex="0" data-id="${it.id}" style="--c:var(${col});grid-column:${it.start+2}/${it.end+3}">${segs}</div></div>`;
    });
  });
  cal.innerHTML=h+"</div>";
}
function showTip(el,x,y){
  const it=items.find(i=>i.id===el.dataset.id);
  tip.innerHTML=`<div class="m">${it.id} · ${it.type.n} · ${it.pts} pts</div><div><b>${it.title}</b></div><div>${it.cat.n}</div><div class="m">${sprints[it.start].name} → ${it.open?"still open in "+sprints[CUR].name:sprints[it.end].name} · ${it.n} sprint${it.n>1?"s":""}${it.n>1?" ("+(it.n-1)+" carried)":""}</div>`;
  tip.hidden=false;
  const r=tip.getBoundingClientRect();
  let left=Math.min(x+14,innerWidth-r.width-12),top=y+16;
  if(top+r.height>innerHeight-8)top=y-r.height-12;
  tip.style.left=Math.max(8,left)+"px";tip.style.top=Math.max(8,top)+"px";
}
const cal=document.getElementById("cal");
cal.addEventListener("pointermove",e=>{const b=e.target.closest(".bar");if(b)showTip(b,e.clientX,e.clientY);else tip.hidden=true});
cal.addEventListener("pointerleave",()=>tip.hidden=true);
cal.addEventListener("click",e=>{const b=e.target.closest(".bar");cal.querySelectorAll(".bar.sel").forEach(x=>x.classList.remove("sel"));if(b){b.classList.add("sel");showTip(b,e.clientX,e.clientY)}});
cal.addEventListener("focusin",e=>{const b=e.target.closest(".bar");if(b){const r=b.getBoundingClientRect();showTip(b,r.left,r.bottom)}});
cal.addEventListener("focusout",()=>tip.hidden=true);
addEventListener("scroll",()=>tip.hidden=true,{passive:true});

// distribution
function renderDist(){
  const groups=state.group==="type"?TYPES:CATS;
  document.getElementById("distBy").textContent=state.group==="type"?"type":"category";
  document.getElementById("dist").innerHTML=groups.map(g=>{
    const a=done.filter(i=>(state.group==="type"?i.type:i.cat)===g);
    const b=[1,2,3,4].map(k=>a.filter(i=>k<4?i.n===k:i.n>=4).length/(a.length||1));
    return `<div class="drow"><span>${g.n}</span><div class="track" role="img" aria-label="${g.n}: ${b.map((v,k)=>(k<3?k+1:"4+")+" sprints "+pct(v)).join(", ")}">${b.map((v,k)=>`<div style="width:${v*100}%;background:var(--d${k+1})" title="${k<3?k+1:"4+"} sprint${k?"s":""}: ${pct(v)}"></div>`).join("")}</div><span class="avg">${fmt(avg(a))}</span></div>`;
  }).join("");
}

// matrix
(function(){
  let h=`<thead><tr><th></th>${CATS.map(c=>`<th>${c.n}</th>`).join("")}</tr></thead><tbody>`;
  TYPES.forEach(t=>{
    h+=`<tr><th>${t.n}</th>`;
    CATS.forEach(c=>{
      const a=done.filter(i=>i.type===t&&i.cat===c);
      if(!a.length){h+=`<td style="color:var(--muted)">–</td>`;return}
      const v=avg(a),k=Math.max(6,Math.min(92,(v-1)/2.6*92));
      h+=`<td style="background:color-mix(in oklab,var(--heat) ${k}%,var(--surface));color:${k>55?"var(--on-heat)":"var(--fg)"}">${fmt(v)}<small>n=${a.length}</small></td>`;
    });
    h+="</tr>";
  });
  document.getElementById("matrix").innerHTML=h+"</tbody>";
})();

// load per sprint
(function(){
  const data=sprints.map((s,i)=>{const a=items.filter(it=>it.start<=i&&it.end>=i);return{s,nw:a.filter(it=>it.start===i).length,cr:a.filter(it=>it.start<i).length}});
  const max=Math.max(...data.map(d=>d.nw+d.cr));const top=Math.ceil(max/5)*5;
  const W=720,H=220,L=30,B=34,T=10,cw=(W-L-6)/N_SPR,bw=cw*.6,y=v=>T+(H-T-B)*(1-v/top);
  let g=`<defs><pattern id="hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="6" height="6" fill="var(--surface)"/><rect width="2.5" height="6" fill="var(--muted)"/></pattern></defs>`;
  for(let v=0;v<=top;v+=5)g+=`<line x1="${L}" x2="${W-4}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="${L-6}" y="${y(v)+3}" text-anchor="end">${v}</text>`;
  data.forEach((d,i)=>{
    const x=L+i*cw+(cw-bw)/2;
    g+=`<rect x="${x}" y="${y(d.cr)}" width="${bw}" height="${y(0)-y(d.cr)}" fill="url(#hatch)" stroke="var(--muted)" stroke-width=".6"><title>${d.s.name}: ${d.cr} carried in</title></rect>`;
    g+=`<rect x="${x}" y="${y(d.cr+d.nw)}" width="${bw}" height="${y(d.cr)-y(d.cr+d.nw)}" fill="var(--accent)"><title>${d.s.name}: ${d.nw} new</title></rect>`;
    const sh=Math.round(d.cr/(d.cr+d.nw||1)*100);
    g+=`<text x="${x+bw/2}" y="${y(d.cr+d.nw)-4}" text-anchor="middle">${sh}%</text>`;
    g+=`<text x="${x+bw/2}" y="${H-B+16}" text-anchor="middle" style="fill:var(--fg)">${d.s.name}</text>`;
  });
  g+=`<text x="${L}" y="${H-4}">% above each bar = share carried in</text>`;
  document.getElementById("load").innerHTML=`<div style="overflow-x:auto"><svg viewBox="0 0 ${W} ${H}" style="width:100%;min-width:520px;display:block" role="img" aria-label="Active items per sprint split into new and carried-in">${g}</svg></div>`;
})();

function seg(id,key,after){
  const el=document.getElementById(id);
  el.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;state[key]=b.dataset.v;el.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",x===b));after()});
}
seg("groupBy","group",()=>{renderCal();renderDist()});
seg("colorBy","color",()=>{legend();renderCal()});
document.getElementById("onlyCarry").addEventListener("change",e=>{state.only=e.target.checked;renderCal()});
legend();renderCal();renderDist();
})();
</script>
````